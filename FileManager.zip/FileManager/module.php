<?php 
/*
 *	Made by SirHyperNova
 *  NamelessMC version 2.0.0-pr3
 *
 *  License: MIT
 *
 *  File Manager Module
 */
$module_version = '1.1.2';
$nameless_version = '2.0.0-pr3';
$module_author = 'SirHyperNova';
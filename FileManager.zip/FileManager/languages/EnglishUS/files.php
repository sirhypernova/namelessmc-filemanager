<?php
/*
 *	Made by Samerton
 *  https://github.com/NamelessMC/Nameless/
 *  NamelessMC version 2.0.0-pr2
 *
 *  License: MIT
 *
 *  EnglishUS Language for example module
 */
 
$language = array(
	'name' => 'Files',
	'view' => 'View',
	'write' => 'Write'
);